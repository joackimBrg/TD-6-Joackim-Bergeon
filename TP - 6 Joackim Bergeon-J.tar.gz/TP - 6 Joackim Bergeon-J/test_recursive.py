import Pile_Liste as lifo
from test import max_pile

def afficher(pile:any) -> any:
    """
    

    Parameters
    ----------
    pile : any
        DESCRIPTION.

    Returns
    -------
    any
        DESCRIPTION.

    """
    print("|----\n|")
    while not(lifo.est_pile_vide(pile)):
        print("| {}\n|".format(lifo.sommet(pile)))
        pile = lifo.depiler(pile)
        print("|----")
    return None

def hauteur_pile_rec(pile: any) -> int:
    if lifo.est_pile_vide(pile):
        return 0
    return 1 + hauteur_pile_rec(lifo.depiler(copie_pile_rec(pile)))

def retourner_pile_rec(pile, copie=None):
    """
    Retourne la pile en paramètre sans rien renvoyer.
    
    Parameters
    ----------
    pile : Pile
        La pile à retourner.
    copie : Pile, optionnel
        Une pile vide utilisée pour stocker temporairement les éléments renversés.
    
    Returns
    -------
    None
    """
    if copie is None:
        copie = lifo.creer_pile_vide()
    if lifo.est_pile_vide(pile):
        while not lifo.est_pile_vide(copie):
            pile = lifo.empiler(pile, lifo.sommet(copie))
            copie = lifo.depiler(copie)
        return
    sommet = lifo.sommet(pile)
    copie = lifo.empiler(copie, sommet)
    retourner_pile_rec(lifo.depiler(pile), copie)


def copie_pile_rec(pile):
    """
    copie la pile en paramètre

    Parameters
    ----------
    pile : pile

    Returns
    -------
    une copie de la pile de manière récursive

    """
    if lifo.est_pile_vide(pile):
        return lifo.creer_pile_vide()
    return lifo.empiler(copie_pile_rec(lifo.depiler(pile)), lifo.sommet(pile))

def spatule_rec(pile, indice, tete=None):
    """
    Retourne les éléments de la pile entre sommet et indice de sorte à ce que l'indice se retrouve au sommet de la pile
    
    Parameters
    ----------
    pile : Pile
        La pile d'origine.
    indice : int
        L'indice de l'élément à placer au sommet.
    tete : Pile, optionnel
        Pile temporaire utilisée pour stocker les éléments pendant la réorganisation (initialement vide).

    Returns
    -------
    Pile
        La pile avec l'élément à l'indice placé au sommet.
    """
    assert hauteur_pile_rec(pile) >= indice
    if tete is None:
        tete = lifo.creer_pile_vide()
    if indice == 0:
        tete = retourner_pile_rec(tete)
        while not lifo.est_pile_vide(tete):
            pile = lifo.empiler(pile, lifo.sommet(tete))
            tete = lifo.depiler(tete)
        return pile

def tri_crepes_rec(pile, hauteur=None):
    """
    trie la pile dans l'orde croissant à partir du sommet

    Parameters
    ----------
    pile : pile
    hauteur : int, optionnel

    Returns
    -------
    pile : la pile copiée et triée

    """    
    if hauteur is None:
        hauteur = hauteur_pile_rec(pile)
    if hauteur <= 1:
        return pile
    return tri_crepes_rec(spatule_rec(spatule_rec(pile,max_pile(copie_pile_rec(pile), hauteur)),hauteur), hauteur - 1)