#!/usr/bin/python3

def creer_pile_vide()->list:
    """
    Construire une instance vide de Pile
    implémentée sur les List Python

    :paramètres: aucun

    :retour: pile vide

    :effets de bord: aucun 

    :pré-conditions: aucune
    """
    return list()

def est_pile_vide(pile: list)->bool:
    """
    Teste si l'instance courante de Pile
    est vide

    :param list pile: l'intance courante\
            de pile

    :return bool: Vrai ssi l'instance courante\
            est vide

    :effets de bord: aucun

    :pré-conditions: aucune
    """
    return len(pile) == 0

def empiler(pile: list, element: any)->list:
    """
    Abonde d'un élément la pile

    :param list pile: instance courante de pile\
            à abonder
    :param any element: élément à ajouter

    :return: copie de liste abondée \
            de l'élément

    :effets de bord: aucun

    :pré-condition: aucune
    """
    return pile + [element]

def depiler(pile: list)->list:
    """
    Supprime l'élément le plus récent de la \
            pile courante

    :param list pile: pile courante
    :return: copie de liste diminuée du\
            dernier élément entré

    :effets de bord: aucun

    :pré-condition: instance courante non vide
    """
    assert not(est_pile_vide(pile)), 'Pile vide !'

    return pile[:-1]

def sommet(pile: list)->any:
    """
    Consulte le dernier élément entré dans la pile

    :param list pile: instance de pile à\
            consulter

    :return: valeur du dernier élément stocké\
            dans la pile

    :effets de bord: aucun

    :pré-condition: la pile est non vide
    """
    assert not(est_pile_vide(pile)), 'Pile vide !'

    return pile[-1]
