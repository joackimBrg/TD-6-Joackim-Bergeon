import Pile_Liste as lifo
from random import shuffle

def afficher(pile:any) -> any:
    """
    

    Parameters
    ----------
    pile : any
        DESCRIPTION.

    Returns
    -------
    any
        DESCRIPTION.

    """
    print("|----\n|")
    while not(lifo.est_pile_vide(pile)):
        print("| {}\n|".format(lifo.sommet(pile)))
        pile = lifo.depiler(pile)
        print("|----")
    return None

def hauteur_pile(P):
    """
    renvoie la hauteur de la pile

    Parameters
    ----------
    P : pile

    Returns
    -------
    n : int

    """
    n = 0
    while not(lifo.est_pile_vide(P)):
        n += 1
        P = lifo.depiler(P)
    return n

def copie_pile(pile):
    """
    Retourne une copie de la pile passée en paramètre.

    Parameters
    ----------
    pile : Pile
        La pile à copier.

    Returns
    -------
    copie : Pile
        Une nouvelle pile avec les mêmes éléments que la pile d'origine.
    """
    copie = lifo.creer_pile_vide()
    temporaire = lifo.creer_pile_vide()
    while not lifo.est_pile_vide(pile):
        sommet = lifo.sommet(pile)
        temporaire = lifo.empiler(temporaire, sommet)
        pile = lifo.depiler(pile)
    while not lifo.est_pile_vide(temporaire):
        sommet = lifo.sommet(temporaire)
        copie = lifo.empiler(copie, sommet)
        pile = lifo.empiler(pile, sommet)
        temporaire = lifo.depiler(temporaire)
    return copie


def max_pile(pile, i):
    """
    Renvoie l'indice du maximum d'une pile entre son sommet et l'indice en paramètre

    Parameters
    ----------
    pile : pile
    i : int

    Returns
    -------
    j : int

    """
    assert i <= hauteur_pile(pile)
    maxi = 0
    indice =  0
    j = 0
    copie = copie_pile(pile)
    while i > 0 :
        i = i-1
        indice += 1
        somm = lifo.sommet(copie)
        if maxi < somm:
            maxi = somm
            j = indice
        copie = lifo.depiler(copie)
    return j

def retourner_pile(pile):
    """
    Retourne la pile en paramètre sans rien renvoyer

    Parameters
    ----------
    pile : pile
    Returns
    -------
    copie : pile

    """
    copie = lifo.creer_pile_vide()
    while not lifo.est_pile_vide(pile):
        sommet = lifo.sommet(pile)
        copie = lifo.empiler(copie, sommet)
        pile = lifo.depiler(pile)
    return copie

def spatule(pile, indice):
    """
    Retourne les éléments de la pile entre sommet et indice de sorte à ce que l'indice se retrouve au sommet de la pile'

    Parameters
    ----------
    pile : pile
    indice : int
    Returns
    -------
    copie : pile

    """
    assert hauteur_pile(pile) >= indice
    copie = copie_pile(pile)
    tete =  lifo.creer_pile_vide()
    for i in range(indice):
        tete = lifo.empiler(tete, lifo.sommet(copie))
        copie = lifo.depiler(copie)
    tete = retourner_pile(tete)
    for i in range(hauteur_pile(tete)):
        copie = lifo.empiler(copie, lifo.sommet(tete))
        tete = lifo.depiler(tete)
    return copie
    
    # Empile l'élément actuel dans la pile temporaire et dépile de la pile principale
    tete = lifo.empiler(tete, lifo.sommet(pile))
    pile = lifo.depiler(pile)
    
    # Appel récursif en décrémentant l'indice
    pile = spatule(pile, indice - 1, tete)
    
    return pile


def tri_crepes(pile):
    """
    trie la pile dans l'orde croissant à partir du sommet

    Parameters
    ----------
    pile : pile

    Returns
    -------
    pile : pile

    """
    hauteur = hauteur_pile(pile)
    for i in range(hauteur):
        imax = max_pile(pile, hauteur -i)
        copie = spatule(pile,imax)
        copie = spatule(copie, hauteur-i)
        pile = copie
    return pile