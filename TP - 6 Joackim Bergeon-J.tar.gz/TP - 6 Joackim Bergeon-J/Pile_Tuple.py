def creer_pile_vide():
    """
    Renvoie une pile vide
    
    Paramètres:
        Aucun
    
    Renvoi:
        une pile vide (tuple)
    """
    return ()

def est_pile_vide(pile):
    """
    Teste si la liste est vide
    
    Paramètres:
        pile la pile à tester
    
    Renvoi:
        Vrai si la pile est vide
        Faux sinon
    """
    return pile == ()

def sommet(pile):
    """
    Renvoie le sommet d'une pile
    
    
    Pré-conditions:
        pile doit etre non-vide
        
    Paramètres:
        pile une pile
    
    Renvoi:
        le premier élément
    """
    assert not est_pile_vide(pile)
    return pile[0]

def depiler(pile):
    """
    Renvoie la pile sans le sommet
    
    
    Pré-conditions:
        pile doit etre non-vide
        
    Paramètres:
        pile une pile
    
    Renvoi:
        la pile sans le sommet
    """
    assert not est_pile_vide(pile)
    return pile[1:]

def empiler(pile, elt):
    """
    Ajoute un élément au sommet de la pile    
    
    Paramètres:
        pile une pile
        elt l'élément à ajouter
    
    Renvoi:
        la pile imbondée de l'élément
    """
    return (elt, pile)