from Pile_List import *

def nota_polo(nota:str)->int:
    """
    calcul un calcul alegibrique composé de somme et de produit dont le caclcul est sous forme d'inversion polonaise.

    Parameters
    ----------
    nota : str
        le calculs sous forme d'inversion polonaise.

    Returns
    -------
    int
        rerourne le resultat du calcul.
    pre_condition: une chaine de charactere non vide, où les characteres soit separer par des espaces.
    
    effet-de-bords: plusieurs

    """
    assert len(nota)!=0
    characte_valide="0123456789*×+"
    parti=nota.split(' ')
    for element in parti:#verifie que le czlcul soit bien écrit
        if element==' ' or element not in characte_valide:
            return AssertionError("Chaque chiffre et operateur doit etre separé d'un espace")
    p = creer_pile_vide()
    compteur = 0
   
    for ele in nota:
    
        if ele.isdigit(): #verifie si l'element et un entier
            p = empiler(p, int(ele)) #empile l'element qui est detecter et le change de type le passant d'un chaine de charactere a un entier
        
            
        elif ele == "+": #verifie si l'element est un signe operatoire d'une addition
            x1 = sommet(p)
            p = depiler(p)
            x2 = sommet(p)
            result = x1 + x2
            p = empiler(p, result)#empile le resultat de la somme
            if compteur != 1: #si c'est la premiere fois que une operation est fait on suprimme le 2 element de la pile
                p.pop(1)
                compteur += 1
            
            


        elif ele == "*" or ele == "×": #verifie si l'element est un signe operatoire d'un produit
            x1 = sommet(p)
            p = depiler(p)
            x2 = sommet(p)
            result = x1 * x2
            p=  empiler(p, result)
            if compteur != 1:
                p.pop(1)
                compteur += 1
            
    return sommet(p) 

print(nota_polo("1 2 3 × + 4 *"))