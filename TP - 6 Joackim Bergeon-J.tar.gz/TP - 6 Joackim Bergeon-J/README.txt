# Projet de Manipulation de Piles et Tri de Crêpes

Ce projet implémente plusieurs fonctions pour manipuler des piles et effectuer des tris de crêpes, ainsi que le calcul d'expressions en notation polonaise inversée (NPI). Le projet utilise une structure de pile implémentée dans un module externe appelé `Pile_Liste` (LIFO).

## Structure du projet

Le projet contient les fichiers suivants :

### 1. `test.py`
Ce fichier contient des fonctions pour manipuler des piles à l'aide d'algorithmes itératifs. Les principales fonctions incluent :
- `afficher(pile)`: Affiche les éléments d'une pile.
- `hauteur_pile(pile)`: Calcule la hauteur d'une pile.
- `copie_pile(pile)`: Retourne une copie de la pile.
- `max_pile(pile, i)`: Trouve l'élément maximum dans une pile jusqu'à un indice donné.
- `retourner_pile(pile)`: Inverse une pile.
- `spatule(pile, indice)`: Replace l'élément à l'indice donné en sommet de pile.
- `tri_crepes(pile)`: Trie la pile en ordre croissant (tri de crêpes).

### 2. `test_recursive.py`
Ce fichier est une version récursive des fonctions définies dans `test.py`. Les fonctions principales incluent :
- `hauteur_pile_rec(pile)`: Calcule récursivement la hauteur d'une pile.
- `retourner_pile_rec(pile)`: Inverse récursivement une pile.
- `copie_pile_rec(pile)`: Copie récursivement une pile.
- `spatule_rec(pile, indice)`: Replace un élément en sommet de pile de manière récursive.
- `tri_crepes_rec(pile)`: Trie récursivement la pile (tri de crêpes).

### 3. `notation_polonaise_inverse.py`
Ce fichier implémente des fonctions pour calculer des expressions algébriques en notation polonaise inversée (NPI). Il contient :
- `nota_polo(nota)`: Calcule une expression algébrique en NPI de façon itérative (supporte les opérations de somme et de produit).
- `nota_polo_rec(nota)`: Version récursive du calcul en NPI.

## Exécution

Pour exécuter les tests de manipulation de piles ou de tri de crêpes, lancez simplement le fichier `test.py` ou `test_recursive.py`.

Pour calculer une expression en notation polonaise inversée, vous pouvez appeler la fonction dans `notation_polonaise_inverse.py`. Par exemple :

```python
from notation_polonaise_inverse import nota_polo, nota_polo_rec

# Calcul d'une expression en NPI
result = nota_polo("3 4 × 2 +")
print(result)  # Sortie attendue : 14

# Version récursive
result_rec = nota_polo_rec("3 4 × 2 +")
print(result_rec)  # Sortie attendue : 14
