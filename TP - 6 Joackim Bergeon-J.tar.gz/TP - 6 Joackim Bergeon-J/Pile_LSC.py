from LSC import *

def creer_pile_vide():
    """
    Renvoie une pile vide
    
    Paramètres:
        Aucun
    
    Renvoi:
        une pile vide (LSC)
    """
    return creer_liste_vide()

def est_pile_vide(pile):
    """
    Teste si la liste est vide
    
    Paramètres:
        pile la pile à tester
    
    Renvoi:
        Vrai si la pile est vide
        Faux sinon
    """
    return pile == creer_liste_vide()

def sommet(pile):
    """
    Renvoie le sommet d'une pile
    
    
    Pré-conditions:
        pile doit etre non-vide
        
    Paramètres:
        pile une pile
    
    Renvoi:
        le premier élément
    """
    return tete(pile)

def depiler(pile):
    """
    Renvoie la pile sans le sommet
    
    
    Pré-conditions:
        pile doit etre non-vide
        
    Paramètres:
        pile une pile
    
    Renvoi:
        la pile sans le sommet
    """
    return queue(pile)

def empiler(pile, elt):
    """
    Ajoute un élément au sommet de la pile    
    
    Paramètres:
        pile une pile
        elt l'élément à ajouter
    
    Renvoi:
        la pile imbondée de l'élément
    """
    return ajouter(pile, elt)